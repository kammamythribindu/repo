<?php 
    echo "Hello Geeks!"; 
?>